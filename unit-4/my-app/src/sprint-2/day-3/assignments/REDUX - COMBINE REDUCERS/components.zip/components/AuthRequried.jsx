import React, { Children } from 'react'

function AuthRequried() {
  return (
    <div>AuthRequried:{Children}</div>
  )
}

export default AuthRequried