import React from 'react'

function Home() {
  return (
    <div>
        <h1>WELCOME..........</h1>
        {/* <h1>Login-Succesful</h1> */}
    </div>
  )
}

export default Home